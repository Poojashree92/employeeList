import React, { useState, ChangeEvent } from 'react';

type Employee = {
  id: string;
  name: string;
  email: string;
};

const Form: React.FC = () => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [form, setForm] = useState<Employee>({ id: '', name: '', email: '' });
  const [xIndex, setXIndex] = useState<number | null>(null);

  const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target;
    setForm({ ...form, [id]: value });
  };

  const addOrUpdate = () => {
    if (xIndex !== null) {
      const updatedEmployees = employees.map((employee, index) =>
        index === xIndex ? form : employee
      );
      setEmployees(updatedEmployees);
      setXIndex(null);
    } else {
      setEmployees([...employees, form]);
    }

    setForm({ id: '', name: '', email: '' });
  };

  const editBtn = (index: number) => {
    setForm(employees[index]);
    setXIndex(index);
  };

  const deleteBtn = (index: number) => {
    setEmployees(employees.filter((_, i) => i !== index));
  };

  return (
    <div className='form'>
        <h1>Employee List</h1>
        <div className='input-box'>
      <input type="text" id="id" placeholder="ID" value={form.id} onChange={handleInputChange} />
      </div>
      <div className='input-box'>
      <input type="text" id="name" placeholder="Name" value={form.name} onChange={handleInputChange} />
      </div>
      <div className='input-box'>
      <input type="email" id="email" placeholder="Email" value={form.email} onChange={handleInputChange} />
      </div>
      <button className='btn' onClick={addOrUpdate}> {xIndex !== null ? 'Update' : 'Add'} </button>

      <table id="employeeTable">
        <thead>
          <tr>
            <th>ID</th> <th>Name</th> <th>Email</th><th>Actions</th>
          </tr>
        </thead>
        <tbody id="employeeList">
          {employees.map((employee, index) => (
            <tr key={index}>
              <td>{employee.id}</td><td>{employee.name}</td><td>{employee.email}</td>
              <td>
                <button onClick={() => editBtn(index)} className="actionBtn">  Edit </button>
                <button onClick={() => deleteBtn(index)} className="actionBtn"> Delete </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Form;
